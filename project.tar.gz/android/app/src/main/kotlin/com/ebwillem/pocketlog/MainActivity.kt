package com.ebwillem.pocketlog

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
